package blueOrigin;

import org.junit.Assert;
import org.junit.Before;
import org.junit.Test;

public class SpaceshipTests {
    private Spaceship spaceship;
    private Astronaut astronaut;

    @Before
    public void setUp() {
        spaceship = new Spaceship("RK", 20);
        astronaut = new Astronaut("Kyle", 30);
    }

    @Test(expected = IllegalArgumentException.class)
    public void checkIfSpaceshipIsFull() {
        spaceship = new Spaceship("RK", 0);
        spaceship.add(astronaut);
    }

    @Test
    public void isAstronautIsAlreadyExists() {
        astronaut = new Astronaut("Kyle", 30);
        Assert.assertEquals("Kyle", astronaut.getName());
    }

    @Test
    public void checkIsAstronautNameIsNull() {
        astronaut = new Astronaut(null, 22);
    }

    @Test
    public void addAstronautInSpaceShip() {
        spaceship.add(astronaut);
    }

    @Test(expected = IllegalArgumentException.class)
    public void addAstronautIsAlreadyInSpaceship() {
        spaceship.add(astronaut);
        astronaut = new Astronaut("Kyle", 30);
        spaceship.add(astronaut);
    }

    @Test
    public void removeAstronautFromSpaceShip(){
        spaceship.remove(astronaut.getName());
        Assert.assertEquals("Kyle",astronaut.getName());
    }
    @Test
    public void checkIfAstronautIsRemoved(){
        spaceship.add(astronaut);
        Assert.assertTrue(spaceship.remove(astronaut.getName()));
    }
    @Test
    public void checkAstronautIsValid(){
        Assert.assertEquals("RK",spaceship.getName());
    }
    @Test(expected = IllegalArgumentException.class)
    public void isCapacityWithZeroCapacity(){
        spaceship = new Spaceship("Rkw",-2);
    }
    @Test(expected = NullPointerException.class)
    public void isSpaceshipNameIsNull(){
        spaceship = new Spaceship(null,22);
    }
}
