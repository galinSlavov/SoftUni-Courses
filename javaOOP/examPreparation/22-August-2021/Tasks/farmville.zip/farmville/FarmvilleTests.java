package farmville;


import org.junit.Assert;
import org.junit.Before;
import org.junit.Test;


public class FarmvilleTests {
    private Farm farm;

    @Before
    public void setUp() {
     this.farm = new Farm("Gosho", 33);
     this.farm.add(new Animal("Leo",23));
    }


    @Test(expected = NullPointerException.class)
    public void setNameIsNull(){
      Farm farm = new Farm(null,33);
    }

    @Test(expected = NullPointerException.class)
    public void setNameIsWhiteSpaces(){
        Farm farm = new Farm(" ",33);
    }

    @Test
    public void setNameIsCorrect(){
        Assert.assertSame("Gosho",farm.getName());
    }

    @Test(expected = IllegalArgumentException.class)
    public void setCapacityIsBelowZero(){
        Farm farm = new Farm("Pesho",-1);
    }

    @Test
    public void setCapacityIsValid(){
        Assert.assertSame(33,farm.getCapacity());
    }

    @Test
    public void getCountIsValid(){
     Assert.assertEquals(1,farm.getCount());
    }

    @Test(expected = IllegalArgumentException.class)
    public void checkAddMethodIsFarmFull(){
     Farm farm = new Farm("DogFarm",0);
     farm.add(new Animal("Dog",33));
    }

    @Test(expected = IllegalArgumentException.class)
    public void checkAddMethodIsAnimalExist(){
     farm.add(new Animal("Leo",33));
    }

    @Test
    public void checkIfThereIsAnimalWithThatType(){
     farm.remove("Leo");
    }

}
