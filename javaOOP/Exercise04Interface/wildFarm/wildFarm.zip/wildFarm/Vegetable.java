package wildFarm;
//created by J.M.

public class Vegetable extends Food{

    public Vegetable(int quantity) {
        super(quantity);
    }
}
