package wildFarm;
//created by J.M.

public class Meat extends Food{

    public Meat(int quantity) {
        super(quantity);
    }
}
