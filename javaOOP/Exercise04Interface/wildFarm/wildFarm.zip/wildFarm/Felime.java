package wildFarm;
//created by J.M.

public abstract class Felime extends Mammal{


    public Felime(String animalType, String animalName, double animalWeight, String livingRegion) {
        super(animalType, animalName, animalWeight, livingRegion);
    }
}

