package militaryElite.interfaces;
//created by J.M.

import java.util.List;

public interface Engineer {

    void addRepair(Repair repair);

    List<Repair> getRepairs();

}
