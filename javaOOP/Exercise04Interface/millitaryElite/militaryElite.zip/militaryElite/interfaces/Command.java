package militaryElite.interfaces;
//created by J.M.

import java.util.List;

public interface Command {

    void execute(List<String> args) ;
}
