package militaryElite.interfaces;
//created by J.M.

public interface SpecialisedSoldier {

    String getCorps();
}
