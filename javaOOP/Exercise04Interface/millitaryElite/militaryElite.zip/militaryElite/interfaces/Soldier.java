package militaryElite.interfaces;
//created by J.M.

public interface Soldier {

    int getId();

    String getFirstName();

    String getLastName();

}
