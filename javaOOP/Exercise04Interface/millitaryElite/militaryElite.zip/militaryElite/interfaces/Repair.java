package militaryElite.interfaces;
//created by J.M.

public interface Repair {
    String getName();

    int getHoursWorked();
}
