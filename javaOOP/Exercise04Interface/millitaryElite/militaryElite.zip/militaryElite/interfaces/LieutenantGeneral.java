package militaryElite.interfaces;
//created by J.M.

public interface LieutenantGeneral {

    void addPrivate(Private soldier);
}
