package militaryElite.interfaces;
//created by J.M.

public interface Mission {

    void completeMission();

    String getCodeName();

    String getState();
}
