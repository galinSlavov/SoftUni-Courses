package militaryElite.interfaces;
//created by J.M.

public interface Spy {

    String getCodeNumber();
}
