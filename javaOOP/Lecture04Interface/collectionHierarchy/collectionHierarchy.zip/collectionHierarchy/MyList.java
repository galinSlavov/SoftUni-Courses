package collectionHierarchy;
//created by J.M.

public interface MyList extends AddRemovable{

    int getUsed();
}
