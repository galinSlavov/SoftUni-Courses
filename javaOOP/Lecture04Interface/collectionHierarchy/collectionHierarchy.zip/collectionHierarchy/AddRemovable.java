package collectionHierarchy;
//created by J.M.

public interface AddRemovable extends Addable{

    String remove();
}
