package collectionHierarchy;
//created by J.M.

public interface Addable {

    int add(String item);
}
